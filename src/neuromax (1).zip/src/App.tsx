import React, { useState, useEffect } from 'react';
import { GameData, Language, UserProgressData } from './types';
import { SaveSystem } from './lib/saveSystem';
import { I18N } from './data/i18n';
import { playAudioFeedback } from './lib/audio';

import { Header } from './components/Header';
import { Dashboard, GAMES_LIST } from './components/Dashboard';
import { SettingsModal } from './components/SettingsModal';
import { EndScreenModal } from './components/EndScreenModal';
import { InstallModal } from './components/InstallModal';
import { PresentationPage } from './components/PresentationPage';

import { PegSolitaireGame } from './components/games/PegSolitaireGame';
import { UnoGame } from './components/games/UnoGame';
import { NamesGame } from './components/games/NamesGame';
import { PairsGame } from './components/games/PairsGame';
import { SequenceGame } from './components/games/SequenceGame';
import { WordSearchGame } from './components/games/WordSearchGame';
import { SudokuGame } from './components/games/SudokuGame';
import { CheckersGame } from './components/games/CheckersGame';
import { GridGames } from './components/games/GridGames';
import { PathGame } from './components/games/PathGame';
import { QuizGames } from './components/games/QuizGames';
import { ChroniGame } from './components/games/ChroniGame';

class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean; error: Error | null }> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("ErrorBoundary caught an error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-900 text-white flex flex-col items-center justify-center p-6 text-center">
          <div className="w-16 h-16 bg-red-500/20 text-red-400 rounded-2xl flex items-center justify-center text-3xl mb-4 border border-red-500/30">
            <i className="fa-solid fa-triangle-exclamation"></i>
          </div>
          <h1 className="text-2xl font-black mb-2">Une erreur s'est produite</h1>
          <p className="text-slate-400 text-sm max-w-md mb-6 font-mono bg-slate-800/80 p-3 rounded-lg border border-slate-700/50 break-all">
            {this.state.error?.message || "Erreur inconnue lors du chargement de l'application."}
          </p>
          <button
            onClick={() => {
              localStorage.clear();
              window.location.reload();
            }}
            className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl transition-all shadow-lg cursor-pointer"
          >
            Réinitialiser & Recharger
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  return (
    <ErrorBoundary>
      <MainApp />
    </ErrorBoundary>
  );
}

const checkIsStandalone = () => {
  if (typeof window === 'undefined') return false;
  return (
    window.matchMedia('(display-mode: standalone)').matches ||
    (window.navigator as any).standalone === true ||
    document.referrer.includes('android-app://') ||
    window.location.search.includes('installed=true') ||
    localStorage.getItem('neuromax_installed') === 'true'
  );
};

function MainApp() {
  const [lang, setLang] = useState<Language>('pt');
  const [progress, setProgress] = useState<UserProgressData>({ games: {}, xp: 0 });
  const [selectedGame, setSelectedGame] = useState<GameData | null>(null);
  const [viewMode, setViewMode] = useState<'presentation' | 'dashboard'>(() => {
    if (checkIsStandalone()) {
      return 'dashboard';
    }
    const saved = localStorage.getItem('neuromax_view');
    if (saved === 'dashboard') {
      return 'dashboard';
    }
    return 'presentation';
  });

  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isInstallOpen, setIsInstallOpen] = useState<boolean>(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [endModal, setEndModal] = useState<{
    isOpen: boolean;
    isWin: boolean;
    leveledUp: boolean;
    stars: number;
  }>({
    isOpen: false,
    isWin: true,
    leveledUp: false,
    stars: 0
  });

  const [replayCount, setReplayCount] = useState<number>(0);

  useEffect(() => {
    const loaded = SaveSystem.load();
    setProgress(loaded);

    if (checkIsStandalone()) {
      setViewMode('dashboard');
    }

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    const handleAppInstalled = () => {
      localStorage.setItem('neuromax_installed', 'true');
      localStorage.setItem('neuromax_view', 'dashboard');
      setViewMode('dashboard');
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleTriggerInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        localStorage.setItem('neuromax_installed', 'true');
        localStorage.setItem('neuromax_view', 'dashboard');
        setViewMode('dashboard');
        setDeferredPrompt(null);
      }
    }
  };

  const handleSelectGame = (game: GameData) => {
    setSelectedGame(game);
    setEndModal({ isOpen: false, isWin: true, leveledUp: false, stars: 0 });
  };

  const handleGoHome = () => {
    setSelectedGame(null);
    setViewMode('dashboard');
    setEndModal({ isOpen: false, isWin: true, leveledUp: false, stars: 0 });
  };

  const handleFinishGame = (isWin: boolean) => {
    if (!selectedGame) return;

    if (isWin) {
      const result = SaveSystem.addWin({ ...progress }, selectedGame.id);
      setProgress({ ...result.data });
      setEndModal({
        isOpen: true,
        isWin: true,
        leveledUp: result.leveledUp,
        stars: result.stars
      });
    } else {
      const gameProg = SaveSystem.getGameProgress(progress, selectedGame.id);
      setEndModal({
        isOpen: true,
        isWin: false,
        leveledUp: false,
        stars: gameProg.stars
      });
    }
  };

  const handleReplayGame = () => {
    setEndModal({ isOpen: false, isWin: true, leveledUp: false, stars: 0 });
    setReplayCount(prev => prev + 1);
  };

  const t = I18N[lang];
  const currentGameProg = selectedGame ? SaveSystem.getGameProgress(progress, selectedGame.id) : null;
  const gameInfo = selectedGame ? (t.gameData as any)[selectedGame.id] || { title: selectedGame.id, inst: '' } : null;

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-slate-50">
      <Header
        lang={lang}
        setLang={setLang}
        progress={progress}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenInstall={() => setIsInstallOpen(true)}
        onOpenPresentation={() => {
          setSelectedGame(null);
          setViewMode('presentation');
        }}
        onOpenGames={() => {
          setSelectedGame(null);
          setViewMode('dashboard');
        }}
        onGoHome={handleGoHome}
        currentView={selectedGame ? 'game' : viewMode}
        isInGame={selectedGame !== null}
      />

      <main className="flex-grow overflow-y-auto relative w-full hide-scrollbar">
        {!selectedGame && viewMode === 'presentation' ? (
          <PresentationPage
            lang={lang}
            setLang={setLang}
            onOpenInstall={() => setIsInstallOpen(true)}
            onStartPlaying={() => {
              localStorage.setItem('neuromax_view', 'dashboard');
              setViewMode('dashboard');
            }}
          />
        ) : !selectedGame ? (
          <Dashboard
            lang={lang}
            progress={progress}
            onSelectGame={handleSelectGame}
            onOpenInstall={() => setIsInstallOpen(true)}
            onOpenPresentation={() => setViewMode('presentation')}
          />
        ) : (
          <div className="w-full h-full flex flex-col bg-slate-50">
            {/* Top Game Navigation Bar */}
            <div className="border-b border-slate-200 p-3 md:p-4 flex flex-row justify-between items-center bg-white shadow-xs z-10 gap-2 shrink-0">
              <button
                onClick={() => {
                  playAudioFeedback('click');
                  handleGoHome();
                }}
                className="tactile-btn text-slate-700 font-bold text-sm md:text-base px-3 py-2 md:px-4 md:py-2 hover:bg-slate-50 flex items-center gap-2"
              >
                <i className="fa-solid fa-chevron-left"></i>
                <span className="hidden sm:inline">{t.btnBack}</span>
              </button>

              <h2 className="text-lg md:text-xl font-black text-slate-800 text-center truncate flex-1 px-2">
                {gameInfo?.title}
              </h2>

              <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 md:px-4 md:py-2 rounded-xl border border-slate-200">
                <span className="text-xs md:text-sm font-bold text-slate-500 uppercase">
                  {t.lvlPrefix}
                </span>
                <span className="text-base md:text-lg font-black text-indigo-700 leading-none">
                  {currentGameProg?.level || 1}
                </span>
              </div>
            </div>

            {/* Game Main Body Container */}
            <div className="flex-grow flex flex-col items-center justify-start p-3 md:p-6 overflow-y-auto relative w-full hide-scrollbar pb-24">
              {/* Stars & Instructions Header */}
              <div className="text-center mb-4 md:mb-6 w-full max-w-2xl bg-white p-3 md:p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-center gap-3">
                <div className="flex gap-1 text-sm md:text-lg">
                  {[0, 1, 2, 3, 4].map(idx => (
                    <i
                      key={idx}
                      className={`fa-solid fa-star ${
                        idx < (currentGameProg?.stars || 0)
                          ? 'text-yellow-500'
                          : 'text-slate-200'
                      }`}
                    ></i>
                  ))}
                </div>
                <div className="h-6 w-px bg-slate-200"></div>
                <h3 className="text-sm md:text-base font-bold text-slate-700 leading-snug flex-1 text-left">
                  {gameInfo?.inst || gameInfo?.desc}
                </h3>
              </div>

              {/* Game Router */}
              <div key={`game-${selectedGame.id}-${currentGameProg?.level || 1}-${replayCount}`} className="w-full flex justify-center items-center">
                {selectedGame.id === 'peg' && (
                  <PegSolitaireGame
                    lang={lang}
                    level={currentGameProg?.level || 1}
                    onFinish={handleFinishGame}
                  />
                )}

                {selectedGame.id === 'uno' && (
                  <UnoGame
                    lang={lang}
                    level={currentGameProg?.level || 1}
                    onFinish={handleFinishGame}
                  />
                )}

                {selectedGame.id === 'names' && (
                  <NamesGame
                    lang={lang}
                    level={currentGameProg?.level || 1}
                    onFinish={handleFinishGame}
                  />
                )}

                {selectedGame.id === 'pairs' && (
                  <PairsGame
                    lang={lang}
                    level={currentGameProg?.level || 1}
                    onFinish={handleFinishGame}
                  />
                )}

                {selectedGame.id === 'sequence' && (
                  <SequenceGame
                    lang={lang}
                    level={currentGameProg?.level || 1}
                    onFinish={handleFinishGame}
                  />
                )}

                {selectedGame.id === 'wordsearch' && (
                  <WordSearchGame
                    lang={lang}
                    level={currentGameProg?.level || 1}
                    onFinish={handleFinishGame}
                  />
                )}

                {selectedGame.id === 'sudoku' && (
                  <SudokuGame
                    lang={lang}
                    level={currentGameProg?.level || 1}
                    onFinish={handleFinishGame}
                  />
                )}

                {selectedGame.id === 'checkers' && (
                  <CheckersGame
                    lang={lang}
                    level={currentGameProg?.level || 1}
                    onFinish={handleFinishGame}
                  />
                )}

                {['oddone', 'target', 'orderNum', 'orderAlpha'].includes(selectedGame.id) && (
                  <GridGames
                    lang={lang}
                    type={selectedGame.id as any}
                    level={currentGameProg?.level || 1}
                    onFinish={handleFinishGame}
                  />
                )}

                {selectedGame.id === 'path' && (
                  <PathGame
                    lang={lang}
                    level={currentGameProg?.level || 1}
                    onFinish={handleFinishGame}
                  />
                )}

                {['recall', 'missing', 'stroop', 'math', 'series', 'greater', 'capitals', 'opposites', 'proverbs'].includes(selectedGame.id) && (
                  <QuizGames
                    lang={lang}
                    type={selectedGame.engine === 'quiz' && selectedGame.params?.type ? selectedGame.params.type : selectedGame.id}
                    params={selectedGame.params}
                    level={currentGameProg?.level || 1}
                    onFinish={handleFinishGame}
                  />
                )}

                {selectedGame.id === 'chroni' && (
                  <ChroniGame
                    lang={lang}
                    level={currentGameProg?.level || 1}
                    onFinish={handleFinishGame}
                  />
                )}
              </div>

              {/* End Screen Modal overlay inside game view */}
              <EndScreenModal
                isOpen={endModal.isOpen}
                isWin={endModal.isWin}
                leveledUp={endModal.leveledUp}
                stars={endModal.stars}
                lang={lang}
                onReplay={handleReplayGame}
                onGoHome={handleGoHome}
              />
            </div>
          </div>
        )}
      </main>

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        lang={lang}
        progress={progress}
        onImportProgress={(newProg) => setProgress(newProg)}
        onOpenInstall={() => setIsInstallOpen(true)}
      />

      <InstallModal
        isOpen={isInstallOpen}
        onClose={() => setIsInstallOpen(false)}
        lang={lang}
        deferredPrompt={deferredPrompt}
        onTriggerInstall={handleTriggerInstall}
      />
    </div>
  );
}
